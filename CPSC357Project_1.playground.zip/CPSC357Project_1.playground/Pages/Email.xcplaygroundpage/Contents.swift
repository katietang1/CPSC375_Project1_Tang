import UIKit
//: My attempt of Email problem, not sure how to take substrings before and after a certain index
func Email (inputEmail: String) -> Bool{
    var isEmail : Bool = true
    if inputEmail.contains(" "){
        isEmail = false
    }
    for char in inputEmail{
        if char == "@"{
            //take substring of string before @
            //assign substring to new variable name
            //take substring of rest of string after @
            //for loop through restofstring
            if char == "." {
                isEmail = true
            }
        }
        else {
            isEmail = false
        }
    }
    return isEmail
}

print(Email(inputEmail: "htang@chapman.edu"))
