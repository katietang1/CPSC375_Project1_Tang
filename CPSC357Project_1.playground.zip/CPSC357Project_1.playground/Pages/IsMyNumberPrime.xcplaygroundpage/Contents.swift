import UIKit

/* **Let's find out if a number is prime!**
 * This program takes an Integer as Input and returns a boolean value depending on if the Integer is prime or not
 * A prime number must be > 1 and cannot be the product of two integers
 * We will use a for loop to iterate a range of numbers to divide from the Integer and check if it has remainders
 */
//: function takes in Int and returns a boolean value
func isPrime(num: Int) -> Bool{
    //: var so that variable is mutable
    var prime: Bool = true
    //: for every number from 2 to Input number, check if prime
    //: we start at 2 and -1 at the end because every number is divisible by one and itself
    for i in 2...num-1 {
        if num % i == 0 {
            prime = false
            //: break statement prevents additonal iteration so that the prime number does not return false
            break;
        }
        else {
            prime = true
        }
    }
    return prime
}

//: calling function with parameters 
print(isPrime(num: 3))
print(isPrime(num: 4))
print(isPrime(num: 7))
print(isPrime(num: 15))
print(isPrime(num: 23))
print(isPrime(num: 100))


