import UIKit

/* **How long do you need to wait? **
 * This program takes four Integers as inputs and prints a string telling the time difference
 * The challange is reverse engineering to calculating around a 24 hr clock
 * We will calculate the hour and minutes seperately, and use if statements to determine if we do a regular calculation or use the 24 hour / 60 min variable
 */

//: function takes in the two times to be compared, return void
func waitingTime(firstHour: Int, firstMinute: Int, secondHour: Int, secondMinute: Int){
    //: declaring constant because values will not change
    let hourInMinutes: Int = 60
    let dayInHours: Int = 24
    //: declearing variable for mutable values
    var diffBetweenHours: Int
    var diffBetweenMinutes: Int
    
    //: Calculate hour difference first
    if firstHour < secondHour {
        diffBetweenHours = secondHour - firstHour
    //: reverse engineering to add the smaller secondHour to the difference of 24hr day and the greater firstHour
    } else { diffBetweenHours = (dayInHours - firstHour) + secondHour
    
    }
    
    //: Calculate minute difference
    if firstMinute < secondMinute {
        diffBetweenMinutes = secondMinute - firstMinute
    } else {
    //: reverse engineering to add the smaller secondMinute to the difference of 60 min hour and the greater firstMinute
        diffBetweenMinutes = (hourInMinutes - firstMinute) + secondMinute
        //: Take account into minute difference and subtract an hour from calculation
        diffBetweenHours -= 1
    }
    
    //: Print results, add 0 to minutes if minute is single digit
    if diffBetweenMinutes <= 9 {
        print("You should wait: \(diffBetweenHours):0\(diffBetweenMinutes)")
    } else {
        print("You should wait: \(diffBetweenHours):\(diffBetweenMinutes)")
    }
}

//: calling function with parameters 
waitingTime(firstHour: 11, firstMinute: 30, secondHour: 13, secondMinute: 15)
waitingTime(firstHour: 18, firstMinute: 55, secondHour: 21, secondMinute: 10)
waitingTime(firstHour: 4, firstMinute: 13, secondHour: 10, secondMinute: 29)


